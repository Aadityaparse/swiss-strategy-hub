/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as actions from "../actions.js";
import type * as agent from "../agent.js";
import type * as api_ from "../api.js";
import type * as auth from "../auth.js";
import type * as auth_emailOtp from "../auth/emailOtp.js";
import type * as banks from "../banks.js";
import type * as chat from "../chat.js";
import type * as decisions from "../decisions.js";
import type * as financials from "../financials.js";
import type * as hindsight_client from "../hindsight_client.js";
import type * as http from "../http.js";
import type * as hypotheses from "../hypotheses.js";
import type * as memory from "../memory.js";
import type * as mockdata from "../mockdata.js";
import type * as simulation from "../simulation.js";
import type * as users from "../users.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  actions: typeof actions;
  agent: typeof agent;
  api: typeof api_;
  auth: typeof auth;
  "auth/emailOtp": typeof auth_emailOtp;
  banks: typeof banks;
  chat: typeof chat;
  decisions: typeof decisions;
  financials: typeof financials;
  hindsight_client: typeof hindsight_client;
  http: typeof http;
  hypotheses: typeof hypotheses;
  memory: typeof memory;
  mockdata: typeof mockdata;
  simulation: typeof simulation;
  users: typeof users;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
